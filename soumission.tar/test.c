#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "stdlib.h"

#include "lib_tar.h"

int main(int argc, char *argv[]) {
    char *str="folder file";
    char *sep=" ";
    char *tok=strtok(str,sep);

}

