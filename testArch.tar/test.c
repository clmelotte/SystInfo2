#include <stdio.h>
#include <stdlib.h>
#include "lib_tar.h"
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
int main(int argc, char *argv[]){
	tar_header_t *header=(tar_header_t *) malloc(512);
	
	int fd=open("./testArch.tar",O_RDONLY);
	//printf(" fd : %i\n", fd);
	int err= lseek(fd,0,SEEK_SET);
	//printf("offset : %i\n",err);
	//printf("errno : %s\n", strerror(errno));
	int ret= read(fd,header,512);
	while(ret!=0){
		printf("name : %s\n", header->name);
                printf("typeflag : %c\n",header->typeflag);
                printf("chksum : %s\n",header->chksum);
                printf("size : %i\n",strtol(header->size,NULL,8));
                printf("version : %s\n",header->version);
		int size = (strtol(header->size,NULL,8)+511)/512;
		printf("%i\n",size);
		for(int i=0;i<=size;i++){
			//printf("%i\n",i+1);
			ret=read(fd,header,512);}
	}
	err = close(fd);
	free (header);
}
