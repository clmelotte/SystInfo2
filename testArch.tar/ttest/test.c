#include <stdio.h>
#include <stdlib.h>
#include "lib_tar.h"
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
int main(int argc, char *argv[]){
	tar_header_t *header=(tar_header_t *) malloc(512);
	
	int fd=open("./testArch.tar",O_RDONLY);
	//printf(" fd : %i\n", fd);
	int err= lseek(fd,0,SEEK_SET);
	//printf("offset : %i\n",err);
	//printf("errno : %s\n", strerror(errno));
	err= read(fd,header,512);
	printf("name : %s\n", header->name);
        printf("typeflag : %c\n",header->typeflag);
        printf("chksum : %s\n",header->chksum);
        printf("size : %s\n",header->size);
        printf("version : %s\n",header->version);
	for(int i=0;i<=11;i++){
		printf("%i\n",i);
		read(fd,header,512);}
	printf("name : %s\n", header->name);
	printf("typeflag : %c\n",header->typeflag);
	printf("chksum : %s\n",header->chksum);
	printf("size : %s\n",header->size);
	printf("version : %s\n",header->version);
	err = close(fd);
	free (header);
}
